import React from 'react';
import './ListContainer.css';

const ListContainer = ({ children }) => <ul className="list-result">{children}</ul>;

export default ListContainer;
