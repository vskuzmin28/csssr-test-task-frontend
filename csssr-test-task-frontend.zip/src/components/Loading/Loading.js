import React from 'react';

const Loading = () => <div className='loading'>Загрузка...</div>;

export default Loading;
