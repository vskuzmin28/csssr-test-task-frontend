export const API_URL = 'https://api.github.com';
export const LOADING = 'LOADING';
export const LOADING_DONE = 'LOADING_DONE';
export const LOADING_ERROR = 'LOADING_ERROR';
