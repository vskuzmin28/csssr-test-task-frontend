import IssueDetail from './IssueDetail';

export default IssueDetail;
