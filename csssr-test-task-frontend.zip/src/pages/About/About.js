import React, { Component } from 'react';

class About extends Component {
  render() {
    return (
      <>
        <h2 className='main__title'>Обо мне</h2>
        <p className='main__desc'>
          ФИО: Виталий<br/> 
          Место проживания: г. Сызрань
        </p>

        <p className='main__desc'>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean feugiat nisl quis sodales
          dapibus. Nulla vel tristique elit. Sed mauris sapien, aliquet non lacinia eu, fringilla
          sit amet tellus. Proin quis mauris vel ex convallis ullamcorper at id dolor.
        </p>

        <p className='main__desc'>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean feugiat nisl quis sodales
          dapibus. Nulla vel tristique elit. Sed mauris sapien, aliquet non lacinia eu, fringilla
          sit amet tellus. Proin quis mauris vel ex convallis ullamcorper at id dolor.
        </p>

        <p className='main__desc'>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean feugiat nisl quis sodales
          dapibus. Nulla vel tristique elit. Sed mauris sapien, aliquet non lacinia eu, fringilla
          sit amet tellus. Proin quis mauris vel ex convallis ullamcorper at id dolor.
        </p>

      </>
    );
  }
}

export default About;
