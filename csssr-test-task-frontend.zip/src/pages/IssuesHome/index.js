import IssuesHome from './IssuesHome';

export default IssuesHome;