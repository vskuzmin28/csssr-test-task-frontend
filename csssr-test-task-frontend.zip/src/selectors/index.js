import getExactIssue from './getExactIssue';

export default {
  getExactIssue
};
